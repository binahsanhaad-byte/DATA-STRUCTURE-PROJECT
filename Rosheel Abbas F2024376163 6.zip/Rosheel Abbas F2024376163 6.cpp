#include <iostream>
using namespace std;

class Array {
private:
    int arr[10];
    int size = 0;

public:

    void traverse() {
        if (size == 0) {
            cout << "Array is empty." << endl;
        } else {
            cout << "Array elements: ";
            for (int i = 0; i < size; i++) {
                cout << arr[i] << " ";
            }
            cout << endl;
        }
    }

    void search(int value) {
        bool found = false;
        for (int i = 0; i < size; i++) {
            if (arr[i] == value) {
                cout << "Element " << value << " found at index " << i << "." << endl;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Element " << value << " not found." << endl;
        }
    }

    void Position_insert(int value, int position) {
        if (size >= 10) {
            cout << "Array is full." << endl;
            return;
        }
        if (position < 0 || position > size) {
            cout << "Invalid position." << endl;
            return;
        }

        for (int i = size; i > position; i--) {
            arr[i] = arr[i - 1];
        }

        arr[position] = value;
        size++;
    }

    void first_insert(int value) {
        Position_insert(value, 0);
    }

    void last_insert(int value) {
        if (size >= 10) {
            cout << "Array full." << endl;
            return;
        }
        arr[size++] = value;
    }

    void update(int position, int newValue) {
        if (position < 0 || position >= size) {
            cout << "Invalid position." << endl;
            return;
        }
        arr[position] = newValue;
    }

    void remove(int position) {
        if (position < 0 || position >= size) {
            cout << "Invalid position." << endl;
            return;
        }

        for (int i = position; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }

        size--;
    }

    void first_remove() { remove(0); }
    void last_remove() {
        if (size > 0) remove(size - 1);
    }
};

int main() {
    Array array;
    int n, value;
    cout << "How many elements you want to add (max 10): ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        cout << "Enter element " << i + 1 << ": ";
        cin >> value;
        array.last_insert(value);
    }

    cout << "\nInitial Array: ";
    array.traverse();


    int choice;

    do {
        cout << "\nOperations:\n";
        cout << "1. Traverse\n";
        cout << "2. Search\n";
        cout << "3. Insert\n";
        cout << "4. Update\n";
        cout << "5. Delete\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            array.traverse();
            break;

        case 2: {
            int value;
            cout << "Enter value to search: ";
            cin >> value;
            array.search(value);
            break;
        }

        case 3: {
            int insChoice, value, position;
            cout << "1. Insert at First\n";
            cout << "2. Insert at Position\n";
            cout << "3. Insert at Last\n";
            cin >> insChoice;

            cout << "Enter value: ";
            cin >> value;

            if (insChoice == 1) array.first_insert(value);
            else if (insChoice == 2) {
                cout << "Position: ";
                cin >> position;
                array.Position_insert(value, position);
            }
            else if (insChoice == 3) array.last_insert(value);
            break;
        }

        case 4: {
            int position, newValue;
            cout << "Position: ";
            cin >> position;
            cout << "New value: ";
            cin >> newValue;
            array.update(position, newValue);
            break;
        }

        case 5: {
            int delChoice, position;
            cout << "1. Delete First\n";
            cout << "2. Delete at Position\n";
            cout << "3. Delete Last\n";
            cin >> delChoice;

            if (delChoice == 1) array.first_remove();
            else if (delChoice == 2) {
                cout << "Position: ";
                cin >> position;
                array.remove(position);
            }
            else if (delChoice == 3) array.last_remove();
            break;
        }

        }

        if (choice != 6) {
            cout << "\nUpdated Array: ";
            array.traverse();
        }

    } while (choice != 6);

    return 0;
}
